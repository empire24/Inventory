<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_Brand extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Brand';

		$this->load->model('model_mbrands');
	}

    /* 
    * It redirects to the company page and displays all the company information
    * It also updates the company information into the database if the 
    * validation for each input field is successfully valid
	*/
	public function index()
	{
		if(!in_array('viewBrand', $this->permission)) {
		   redirect('dashboard', 'refresh');
		 }

		$brand_data = $this->model_mbrands->getBrandData();

		$result = array();
		foreach ($brand_data as $k => $v) {

			$result[$k]['brand_info'] = $v;

				}

		$this->data['brand_data'] = $result;

		$this->render_template('brand/index', $this->data);
    }
    public function fetchBrandData()
	{
		$result = array('data' => array());

		$data = $this->model_mbrands->getBrandData();
    

		foreach ($data as $key => $value) {

           // button
            $buttons = '';
            if(in_array('updateBrand', $this->permission)) {
    			$buttons .= '<a href="'.base_url('Controller_Brand/update/'.$value['id']).'" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i></a>';
            }

            if(in_array('deleteBrand', $this->permission)) { 
    			$buttons .= ' <button type="button" class="btn btn-danger btn-sm" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
            }
			

			$img = '<img src="'.base_url($value['logo']).'" alt="'.$value['name'].'" class="img-circle" width="50" height="50" />';

           
           

			$result['data'][$key] = array(
				
				// $value['sku'],
				$value['brand_code'],
				$value['brand_name'],
                $value['phno'] ,
        
                $value['phno'] ,
        
				$buttons
			);
		} // /foreach

		echo json_encode($result);
	}	

    public function create()
	{
        // echo 'came';
        // exit();
		if(!in_array('createBrand', $this->permission)) {
        //     redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('brand_code', 'brand code', 'trim|required');
		$this->form_validation->set_rules('brand_name', 'brand name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('brand_local_name', 'brand local name', 'trim|required');
		$this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		$this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case
        	$upload_image = $this->upload_image();

        	$data = array(
				
				'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				'logo' => $upload_image,
        		
				
        	);

        	$create = $this->model_mbrands->create($data);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Brand/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Brand/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('brand/create', $this->data);
        }	
	}

    /*
    * This function is invoked from another function to upload the image into the assets folder
    * and returns the image path
    */
	public function upload_image()
    {
    	// assets/images/product_image
        $config['upload_path'] = 'assets/images/logo_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('logo_image'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['logo_image']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
	}
	public function update($brand_id)
	{      
        if(!in_array('updateBrand', $this->permission)) {
            // redirect('dashboard', 'refresh');
        }

        if(!$brand_id) {
            // redirect('dashboard', 'refresh');
        }

        $this->form_validation->set_rules('product_name', 'Product name', 'trim|required');
        // $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
        $this->form_validation->set_rules('price', 'Price', 'trim|required');
        $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
        $this->form_validation->set_rules('store', 'Store', 'trim|required');
        $this->form_validation->set_rules('availability', 'Availability', 'trim|required');

        if ($this->form_validation->run() == TRUE) {
            // true case
            
            $data = array(
                'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				  );

            
            if($_FILES['brand_image']['size'] > 0) {
                $upload_image = $this->upload_image();
                $upload_image = array('logo' => $upload_image);
                
                $this->model_mbrands->update($upload_image, $brand_id);
            }

            $update = $this->model_mbrands->update($data, $brand_id);
            if($update == true) {
                $this->session->set_flashdata('success', 'Successfully updated');
                redirect('Controller_Brand/', 'refresh');
            }
            else {
                $this->session->set_flashdata('errors', 'Error occurred!!');
                redirect('Controller_Brand/update/'.$brand_id, 'refresh');
            }
        }
       
            $brand_data = $this->model_mbrands->getBrandData($brand_id);
            $this->data['brand_data'] = $brand_data;
            $this->render_template('brand/edit', $this->data); 
        }   
	

    /*
    * It removes the data from the database
    * and it returns the response into the json format
    */
	public function delete($id)
	{
		if(!in_array('deleteBrand', $this->permission)) {
			redirect('dashboard', 'refresh');
		}

		if($id) {
			if($this->input->post('confirm')) {
					$delete = $this->model_mbrands->delete($id);
					if($delete == true) {
		        		$this->session->set_flashdata('success', 'Successfully removed');
		        		redirect('Controller_Brand/', 'refresh');
		        	}
		        	else {
		        		$this->session->set_flashdata('error', 'Error occurred!!');
		        		redirect('Controller_Brand/delete/'.$id, 'refresh');
		        	}

			}	
			else {
				$this->data['id'] = $id;
				$this->render_template('brand/delete', $this->data);
			}	
		}
	}
}

