<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_Branch extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Branch';

		$this->load->model('model_mBranch');
	}

    /* 
    * It redirects to the company page and displays all the company information
    * It also updates the company information into the database if the 
    * validation for each input field is successfully valid
	*/
	public function index()
	{
		if(!in_array('viewBrand', $this->permission)) {
		  redirect('dashboard', 'refresh');
		 }

		$branch_data = $this->model_mBranch->getBranchData();

		$result = array();
		foreach ($branch_data as $k => $v) {

			$result[$k]['branch_info'] = $v;

				}

		$this->data['branch_data'] = $result;

		$this->render_template('branch/index', $this->data);
    }
    public function create()
	{
        // echo 'came';
        // exit();
		if(!in_array('createBranch', $this->permission)) {
           redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('branch_id', 'branch id ', 'trim|required');
		// $this->form_validation->set_rules('branch_name', 'branch name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('local_name', ' local name', 'trim|required');
		// $this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        // $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		// $this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case

        	$data = array(
				
				'branch_id'=>$this->input->post('branch_id'),
                'english_name' => $this->input->post('english_name'),
                'local_name' => $this->input->post('local_name'),
        		
        		'tel_no' => $this->input->post('tel_no'),
        		'fax' => $this->input->post('fax'),
				'addrs' => $this->input->post('addrs'),
				
        		
				
        	);

        	$create = $this->model_mBranch->create($data);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Branch/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Branch/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('branch/create', $this->data);
        }	
	}
	public function update($branchid)
	{      
        if(!in_array('updateBrand', $this->permission)) {
            // redirect('dashboard', 'refresh');
        }

        if(!$branchid) {
            // redirect('dashboard', 'refresh');
        }
		$this->form_validation->set_rules('branch_id', 'branch id ', 'trim|required');
		
        // $this->form_validation->set_rules('product_name', 'Product name', 'trim|required');
        // // $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
        // $this->form_validation->set_rules('price', 'Price', 'trim|required');
        // $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
        // $this->form_validation->set_rules('store', 'Store', 'trim|required');
        // $this->form_validation->set_rules('availability', 'Availability', 'trim|required');

        if ($this->form_validation->run() == TRUE) {
            // true case
            
            $data = array(
				'branch_id'=>$this->input->post('branch_id'),
                'english_name' => $this->input->post('english_name'),
                'local_name' => $this->input->post('local_name'),
        		
        		'tel_no' => $this->input->post('tel_no'),
        		'fax' => $this->input->post('fax'),
				'addrs' => $this->input->post('addrs'),
				  );

            
            $update = $this->model_mBranch->update($data, $branchid);
            if($update == true) {
                $this->session->set_flashdata('success', 'Successfully updated');
                redirect('Controller_Branch/', 'refresh');
            }
            else {
                $this->session->set_flashdata('errors', 'Error occurred!!');
                redirect('Controller_Branch/update/'.$branchid, 'refresh');
            }
        }
       
            $branch_data = $this->model_mBranch->getBranchData($branchid);
            $this->data['branch_data'] = $branch_data;
            $this->render_template('branch/edit', $this->data); 
		}   
public function delete($id)
		{
			if(!in_array('deleteBrand', $this->permission)) {
				redirect('dashboard', 'refresh');
			}
	
			if($id) {
				if($this->input->post('confirm')) {
						$delete = $this->model_mBranch->delete($id);
						if($delete == true) {
							$this->session->set_flashdata('success', 'Successfully removed');
							redirect('Controller_Branch/', 'refresh');
						}
						else {
							$this->session->set_flashdata('error', 'Error occurred!!');
							redirect('Controller_Branch/delete/'.$id, 'refresh');
						}
	
				}	
				else {
					$this->data['id'] = $id;
					$this->render_template('branch/delete', $this->data);
				}	
			}
		}
	}	