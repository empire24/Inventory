

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Add User
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Member</li>
      </ol>
    </section>
<section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
    

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
        <div class="col-md-12 col-xs-12">
          
          <?php if($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $this->session->flashdata('success'); ?>
            </div>
          <?php elseif($this->session->flashdata('error')): ?>
            <div class="alert alert-error alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $this->session->flashdata('error'); ?>
            </div>
          <?php endif; ?>

         
            <form method="POST" action="<?php base_url('Controller_Members/create') ?>" accept-charset="UTF-8" id="user_add_form" novalidate="novalidate">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-2">
<div class="form-group">
<label for="surname">Prefix:</label>
<input class="form-control" placeholder="Mr / Mrs / Miss" name="surname" type="text" id="surname">
</div>
</div>
<div class="col-md-5">
<div class="form-group">
<label for="first_name">First Name:*</label>
<input class="form-control" required="" placeholder="First Name" name="first_name" type="text" id="first_name" aria-required="true">
</div>
</div>
<div class="col-md-5">
<div class="form-group">
<label for="last_name">Last Name:</label>
<input class="form-control" placeholder="Last Name" name="last_name" type="text" id="last_name">
</div>
</div>
<div class="clearfix"></div>
<div class="col-md-4">
<div class="form-group">
<label for="email">Email:*</label>
<input class="form-control" required="" placeholder="Email" name="email" type="text" id="email" aria-required="true">
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<div class="checkbox">
<br>
<label>
<div class="icheckbox_square-blue checked" style="position: relative;"><input class="input-icheck status" checked="" name="" type="checkbox" value="active" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div> Is active ?
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Check/Uncheck to make a user active/inactive." data-html="true" data-trigger="hover"></i> </div>
</div>
</div>
</div>

</div> </div>
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Roles and Permissions</h3>
</div>
<div class="box-body">
<div class="col-md-4">
<div class="form-group">
<div class="checkbox">
<label class="">
 <div class="icheckbox_square-blue checked" style="position: relative;"><input class="input-icheck" id="allow_login" checked="checked" name="allow_login" type="checkbox" value="1" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div> Allow login
</label>
</div>
</div>
</div>
<div class="clearfix"></div>
<div class="user_auth_fields">
<div class="col-md-4">
<div class="form-group">
<label for="username">Username:</label>
<input class="form-control" placeholder="Username" name="username" type="text" id="username">
<p class="help-block">Leave blank to auto generate username</p>
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label for="password">Password:*</label>
<input class="form-control" required="" placeholder="Password" name="password" type="password" value="" id="password" aria-required="true">
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label for="confirm_password">Confirm Password:*</label>
<input class="form-control" required="" placeholder="Confirm Password" name="confirm_password" type="password" value="" id="confirm_password" aria-required="true">
</div>
</div>
</div>
<div class="clearfix"></div>
<div class="col-md-6">
<div class="form-group">
<label for="role">Role:*</label> <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Admin can access all locations" data-html="true" data-trigger="hover"></i> <select class="form-control select2 select2-hidden-accessible" id="role" name="role" tabindex="-1" aria-hidden="true"><option value="1">Admin</option><option value="2">Cashier</option></select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 532.5px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-role-container"><span class="select2-selection__rendered" id="select2-role-container" title="Admin">Admin</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
</div>
</div>
<div class="clearfix"></div>
<div class="col-md-3">
<h4>Access locations <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Choose all locations this role can access. All data for the selected location will only be displayed to the user.<br/><br/><small>For Example: You can use this to define <i>Store Manager / Cashier / Stock manager / Branch Manager, </i>of particular Location.</small>" data-html="true" data-trigger="hover"></i></h4>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<div class="icheckbox_square-blue checked" style="position: relative;"><input class="input-icheck" checked="checked" name="access_all_locations" type="checkbox" value="access_all_locations" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div> All Locations
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="If <b>All Locations</b> selected this role will have permission to access all business locations" data-html="true" data-trigger="hover"></i> </div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<div class="icheckbox_square-blue" style="position: relative;"><input class="input-icheck" name="location_permissions[]" type="checkbox" value="location.1" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div> Sunshine Enterprise
</label>
</div>
</div>
</div>
</div>

</div> </div>
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Sales</h3>
</div>
<div class="box-body">
<div class="col-md-4">
<div class="form-group">
<label for="cmmsn_percent">Sales Commission Percentage (%):</label> <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Used only if Sales Commission Agent Type setting is: 'Logged In user' or 'Select from users list'" data-html="true" data-trigger="hover"></i> <input class="form-control input_number" placeholder="Sales Commission Percentage (%)" name="cmmsn_percent" type="text" id="cmmsn_percent">
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label for="max_sales_discount_percent">Max sales discount percent:</label> <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Maximum discount percentage that a user can give during sale. Leave it blank for no constraints" data-html="true" data-trigger="hover"></i> <input class="form-control input_number" placeholder="Max sales discount percent" name="max_sales_discount_percent" type="text" id="max_sales_discount_percent">
</div>
</div>
<div class="clearfix"></div>
<div class="col-md-4">
<div class="form-group">
<div class="checkbox">
<br>
<label>
<div class="icheckbox_square-blue" style="position: relative;"><input class="input-icheck" id="selected_contacts" name="selected_contacts" type="checkbox" value="1" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div> Allow Selected Contacts
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Only allow access to selected contacts in sells/purchase customer/supplier search box" data-html="true" data-trigger="hover"></i> </div>
</div>
</div>
<div class="col-sm-4 hide selected_contacts_div">
<div class="form-group">
<label for="selected_contacts">Select Contacts:</label>
<div class="form-group">
<select class="form-control select2 select2-hidden-accessible" multiple="" style="width: 100%;" name="selected_contact_ids[]" tabindex="-1" aria-hidden="true"><option value="5">Mr. SABRAS COLDRINKS</option><option value="6"> DARSHAN BHAI - BHAVANI ENTERPRISE(CO0003)</option><option value="7"> SHIVAM COLDRINKS - (CO0004)</option><option value="8"> JOSH ICE CREAM COLDRINKS - (CO0005)</option><option value="9"> DREAM MEDICAL - (CO0006)</option><option value="10"> KGN CORPORATION ( BAKERS N MORE ) - (CO0007)</option><option value="11"> ASHAPURA GENERAL STORE - (CO0008)</option><option value="12"> KAVERI SWEET CORNER - (CO0009)</option><option value="13"> MEGHA KIRANA - (CO0010)</option><option value="14"> NEW ONE KIRANA - (CO0011)</option><option value="15"> SHREE KRISHNA COLDRINKS - (CO0012)</option><option value="16"> GOPAL DAIRY - (CO0013)</option><option value="17"> DIL KHUSH PAAN - (CO0014)</option><option value="18"> ASHAPURA KIRANA STORE - (CO0015)</option><option value="19"> SHREE KSHEMKARI KIRANA - (CO0016)</option><option value="20"> PARMATMA KIRANA STORE - (CO0017)</option><option value="21"> KETAN SHEETAL ICE CREAM - (CO0018)</option><option value="22"> SORATHIYA TEA HOUSE - (CO0019)</option><option value="23"> JAY JALARAM SWEET - (CO0020)</option></select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="textbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
</div>
</div>
</div>
</div>

</div> </div>
</div>
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">More Informations</h3>
</div>
<div class="box-body">
<div class="form-group col-md-3">
<label for="user_dob">Date of birth:</label>
<input class="form-control" placeholder="Date of birth" readonly="" id="user_dob" name="dob" type="text">
</div>
<div class="form-group col-md-3">
<label for="gender">Gender:</label>
<select class="form-control" id="gender" name="gender"><option selected="selected" value="">Please Select</option><option value="male">Male</option><option value="female">Female</option><option value="others">Others</option></select>
</div>
<div class="form-group col-md-3">
<label for="marital_status">Marital Status:</label>
<select class="form-control" id="marital_status" name="marital_status"><option selected="selected" value="">Marital Status</option><option value="married">Married</option><option value="unmarried">Unmarried</option><option value="divorced">Divorced</option></select>
</div>
<div class="form-group col-md-3">
<label for="blood_group">Blood Group:</label>
<input class="form-control" placeholder="Blood Group" name="blood_group" type="text" id="blood_group">
</div>
<div class="clearfix"></div>
<div class="form-group col-md-3">
<label for="contact_number">Contact Number:</label>
<input class="form-control" placeholder="Contact Number" name="contact_number" type="text" id="contact_number">
</div>
<div class="form-group col-md-3">
<label for="fb_link">Facebook Link:</label>
<input class="form-control" placeholder="Facebook Link" name="fb_link" type="text" id="fb_link">
</div>
<div class="form-group col-md-3">
<label for="twitter_link">Twitter Link:</label>
<input class="form-control" placeholder="Twitter Link" name="twitter_link" type="text" id="twitter_link">
</div>
<div class="form-group col-md-3">
<label for="social_media_1">Social Media 1:</label>
<input class="form-control" placeholder="Social Media 1" name="social_media_1" type="text" id="social_media_1">
</div>
<div class="clearfix"></div>
<div class="form-group col-md-3">
<label for="social_media_2">Social Media 2:</label>
<input class="form-control" placeholder="Social Media 2" name="social_media_2" type="text" id="social_media_2">
</div>
<div class="form-group col-md-3">
<label for="custom_field_1">Custom field 1:</label>
<input class="form-control" placeholder="Custom field 1" name="custom_field_1" type="text" id="custom_field_1">
</div>
<div class="form-group col-md-3">
<label for="custom_field_2">Custom field 2:</label>
<input class="form-control" placeholder="Custom field 2" name="custom_field_2" type="text" id="custom_field_2">
</div>
<div class="form-group col-md-3">
<label for="custom_field_3">Custom field 3:</label>
<input class="form-control" placeholder="Custom field 3" name="custom_field_3" type="text" id="custom_field_3">
</div>
<div class="form-group col-md-3">
<label for="custom_field_4">Custom field 4:</label>
<input class="form-control" placeholder="Custom field 4" name="custom_field_4" type="text" id="custom_field_4">
</div>
<div class="form-group col-md-3">
<label for="guardian_name">Guardian Name:</label>
<input class="form-control" placeholder="Guardian Name" name="guardian_name" type="text" id="guardian_name">
</div>
<div class="form-group col-md-3">
<label for="id_proof_name">ID proof name:</label>
<input class="form-control" placeholder="ID proof name" name="id_proof_name" type="text" id="id_proof_name">
</div>
<div class="form-group col-md-3">
<label for="id_proof_number">ID proof number:</label>
<input class="form-control" placeholder="ID proof number" name="id_proof_number" type="text" id="id_proof_number">
</div>
<div class="clearfix"></div>
<div class="form-group col-md-6">
<label for="permanent_address">Permanent Address:</label>
<textarea class="form-control" placeholder="Permanent Address" rows="3" name="permanent_address" cols="50" id="permanent_address"></textarea>
</div>
<div class="form-group col-md-6">
<label for="current_address">Current Address:</label>
<textarea class="form-control" placeholder="Current Address" rows="3" name="current_address" cols="50" id="current_address"></textarea>
</div>
<div class="col-md-12">
<hr>
<h4>Bank Details:</h4>
</div>
<div class="form-group col-md-3">
<label for="account_holder_name">Account Holder's Name:</label>
<input class="form-control" id="account_holder_name" placeholder="Account Holder's Name" name="bank_details[account_holder_name]" type="text">
</div>
<div class="form-group col-md-3">
<label for="account_number">Account Number:</label>
<input class="form-control" id="account_number" placeholder="Account Number" name="bank_details[account_number]" type="text">
</div>
<div class="form-group col-md-3">
<label for="bank_name">Bank Name:</label>
<input class="form-control" id="bank_name" placeholder="Bank Name" name="bank_details[bank_name]" type="text">
</div>
<div class="form-group col-md-3">
<label for="bank_code">Bank Identifier Code:</label> <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="A unique code to identify the bank in your country, for example: IFSC code" data-html="true" data-trigger="hover"></i> <input class="form-control" id="bank_code" placeholder="Bank Identifier Code" name="bank_details[bank_code]" type="text">
</div>
<div class="form-group col-md-3">
<label for="branch">Branch:</label>
<input class="form-control" id="branch" placeholder="Branch" name="bank_details[branch]" type="text">
</div>
<div class="form-group col-md-3">
<label for="tax_payer_id">Tax Payer ID:</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Tax number id of the employee, for example, PAN card in India" data-html="true" data-trigger="hover"></i> <input class="form-control" id="tax_payer_id" placeholder="Tax Payer ID" name="bank_details[tax_payer_id]" type="text">
</div>
</div>

</div> </div>
</div>
<div class="row">
<div class="col-md-12">
<button type="submit" class="btn btn-primary pull-right" id="submit_user_button">Save</button>
</div>
</div>
</form>
          </div>
          <!-- /.box -->
        </div>
        <!-- col-md-12 -->
      </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
       
      </div>
      <!-- /.box -->

 

    </section>