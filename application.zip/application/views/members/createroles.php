<section class="content-header">
<h1>Add Role</h1>
</section>

<section class="content">
<div class="box box-primary">
<div class="box-body">
<form method="POST" action="http://pos.siddconsultancy.com/roles" accept-charset="UTF-8" id="role_add_form"><input name="_token" type="hidden" value="UFkYFH5WO6ml6pHfcUzQJX3c1nEx5YvbIt08QoaP">
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label for="name">Role Name:*</label>
<input class="form-control" required placeholder="Role Name" name="name" type="text" id="name">
</div>
</div>
</div>
<div class="row">
<div class="col-md-3">
<label>Permissions:</label>
</div>
</div>
<div class="row check_group">
<div class="col-md-1">
<h4>User</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="user.view"> View user
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="user.create"> Add user
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="user.update"> Edit user
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="user.delete"> Delete user
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Roles</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="roles.view"> View role
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="roles.create"> Add Role
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="roles.update"> Edit Role
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="roles.delete"> Delete role
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Supplier</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
 <input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="supplier.view"> View supplier
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="supplier.create"> Add supplier
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="supplier.update"> Edit supplier
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="supplier.delete"> Delete supplier
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Customer</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="customer.view"> View customer
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="customer.create"> Add customer
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="customer.update"> Edit customer
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="customer.delete"> Delete customer
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Product</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="product.view"> View product
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="product.create"> Add product
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="product.update"> Edit product
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="product.delete"> Delete product
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="product.opening_stock"> Add Opening Stock
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="view_purchase_price">
View Purchase Price
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Permission to view purchase price in product details" data-html="true" data-trigger="hover"></i> </div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Purchase & Stock Adjustment</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.view"> View purchase &amp; Stock Adjustment
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.create"> Add purchase &amp; Stock Adjustment
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.update"> Edit purchase &amp; Stock Adjustment
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.delete"> Delete purchase &amp; Stock Adjustment
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.payments">
Add/Edit/Delete Payments
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Permission to Add/Edit/Delete Payments in List Purchases." data-html="true" data-trigger="hover"></i> </div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase.update_status">
Update Status
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="view_own_purchase">
View own purchase only
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Sell</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sell.view"> View POS sell
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sell.create"> Add POS sell
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sell.update"> Edit POS sell
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sell.delete"> Delete POS sell
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="direct_sell.access"> Access sell
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="list_drafts"> List Drafts
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="list_quotations"> List quotations
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="view_own_sell_only"> View own sell only
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sell.payments">
Add/Edit/Delete Payments
</label>
<i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="Permission to Add/Edit/Delete Payments in List Sells / List POS screen." data-html="true" data-trigger="hover"></i> </div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="edit_product_price_from_sale_screen">
Edit product price from sales screen
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="edit_product_price_from_pos_screen">
Edit product price from POS screen
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="edit_product_discount_from_sale_screen">
Edit product discount from Sale screen
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="edit_product_discount_from_pos_screen">
Edit product discount from POS screen
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="discount.access">
Add/Edit/Delete Discount
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="access_shipping">
Access Shipments
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Brand</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="brand.view"> View brand
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="brand.create"> Add brand
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="brand.update"> Edit brand
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="brand.delete"> Delete brand
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Tax rate</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="tax_rate.view"> View tax rate
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="tax_rate.create"> Add tax rate
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="tax_rate.update"> Edit tax rate
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="tax_rate.delete"> Delete tax rate
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Unit</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
 </div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="unit.view"> View unit
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="unit.create"> Add unit
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="unit.update"> Edit unit
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="unit.delete"> Delete unit
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Category</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="category.view"> View category
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="category.create"> Add category
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="category.update"> Edit category
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="category.delete"> Delete category
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Report</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="purchase_n_sell_report.view"> View purchase &amp; sell report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="tax_report.view"> View Tax report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="contacts_report.view"> View Supplier &amp; Customer report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="expense_report.view"> View expense report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="profit_loss_report.view"> View profit/loss report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="stock_report.view"> View stock report, stock adjustment report &amp; stock expiry report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="trending_product_report.view"> View trending product report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="register_report.view"> View register report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="sales_representative.view"> View sales representative report
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="view_product_stock_value"> View product stock value
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Settings</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="business_settings.access"> Access business settings
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="barcode_settings.access"> Access barcode settings
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="invoice_settings.access"> Access invoice settings
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="expense.access"> Access expenses
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="view_own_expense">
View own expense only
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="access_printers">
Access printers
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-3">
<h4>Home <i class="fa fa-info-circle text-info hover-q no-print " aria-hidden="true" data-container="body" data-toggle="popover" data-placement="auto bottom" data-content="If unchecked only Welcome message will be displayed in Home." data-html="true" data-trigger="hover"></i></h4>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" checked="checked" name="permissions[]" type="checkbox" value="dashboard.data"> View Home data
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-3">
<h4>Account</h4>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="account.access"> Access Accounts
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row check_group">
<div class="col-md-1">
<h4>Bookings</h4>
</div>
<div class="col-md-2">
<div class="checkbox">
<label>
<input type="checkbox" class="check_all input-icheck"> Select all
</label>
</div>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="crud_all_bookings"> Add/Edit/View all bookings
</label>
</div>
</div>
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" name="permissions[]" type="checkbox" value="crud_own_bookings"> Add/Edit/View own bookings
</label>
</div>
</div>
</div>
</div>
<hr>
<div class="row">
<div class="col-md-3">
<h4>Access selling price groups</h4>
</div>
<div class="col-md-9">
<div class="col-md-12">
<div class="checkbox">
<label>
<input class="input-icheck" checked="checked" name="permissions[]" type="checkbox" value="access_default_selling_price"> Default Selling Price
</label>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<button type="submit" class="btn btn-primary pull-right">Save</button>
</div>
</div>
</form>
</div>

</div></section>

