<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Brand
              </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Brand</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-md-12 col-xs-12">

          <?php if($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $this->session->flashdata('success'); ?>
            </div>
          <?php elseif($this->session->flashdata('error')): ?>
            <div class="alert alert-error alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $this->session->flashdata('error'); ?>
            </div>
          <?php endif; ?>
          
          <?php if(in_array('createBrand', $user_permission)): ?>
            <a href="<?php echo base_url('Controller_Brand/create') ?>" class="btn btn-primary">Add New</a>
            <br /> <br />
          <?php endif; ?>


          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="userTable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Brand Code</th>
                  <th>Brand Name</th>
                  <th>Phone</th>
                  <th>Address1</th>
                  <th>Website</th>
                 
                  <?php if(in_array('updateBrand', $user_permission) || in_array('deleteBrand', $user_permission)): ?>
                  <th>Action</th>
                <?php endif; ?>
              
                <tbody>
                  <?php if($brand_data): ?>                  
                    <?php foreach ($brand_data as $k => $v): ?>
                      <tr>
                        <td><?php echo $v['brand_info']['brand_code']; ?></td>
                        <td><?php echo $v['brand_info']['brand_name']; ?></td>
                        <td><?php echo $v['brand_info']['phno'] ; ?></td>
                          <td><?php echo $v['brand_info']['addrs1']; ?></td>
                          <td><?php echo $v['brand_info']['website']; ?></td>

                        <?php if(in_array('updateBrand', $user_permission) || in_array('deleteBrand', $user_permission)): ?>
                  
                        <td>
  <?php if(in_array('updateBrand', $user_permission)): ?>
                            <a href="<?php echo base_url('Controller_Brand/update/'.$v['brand_info']['id']) ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                          <?php endif; ?>
                          <?php if(in_array('deleteUser', $user_permission)): ?>
                            <a href="" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete_users<?php echo $v['brand_info']['id']; ?>"><i class="fa fa-trash"></i></a>

                             <div class="modal fade" id="delete_users<?php echo $v['brand_info']['id'];?>" role="dialog">
                            <div class="modal-dialog modal-sm">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h4 class="modal-title">Are You Sure ? </h4>
                                </div>
                                <div class="modal-body">
                                  <p>Want to delete <?php echo $v['brand_info']['brand_name'] ; ?></p>
                                </div>
                                <div class="modal-footer">
                                <form action="<?php echo base_url('Controller_Brand/delete/'.$v['brand_info']['id']) ?>" method="post">
                             
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                               <input type="submit" class="btn btn-danger" name="confirm" value="Delete">
                              </form>
                                  
                                </div>
                              </div>
                            </div>
                          </div>
                          <?php endif; ?>
                        </td>
                      <?php endif; ?>
                      </tr>
                    <?php endforeach ?>
                  <?php endif; ?>
                </tbody>
                        
                </tr>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- col-md-12 -->
      </div>
      <!-- /.row -->
      

    </section>
    <!-- /.content -->
  </div>
    


    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#userTable').DataTable({
         dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'print'
        ]
      });
     
        
      $("#brandNav").addClass('active');
     
      });
  </script>
